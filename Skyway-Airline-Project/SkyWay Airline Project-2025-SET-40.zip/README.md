# SkyLink Airways - Airline Reservation & Flight Management System

A console-based C++ application for managing flights, passengers, ticket
bookings, cancellations, and reports for a regional airline.

## Folder Structure

```
airline_project/
├── include/          All header (.h) files
├── src/              All implementation (.cpp) files
├── data/
│   └── flights.txt   Sample data file (10 flights, 8 passengers, 5 tickets)
├── Makefile
└── README.md
```

## How to Build

Requirements: g++ with C++17 support.

From inside the `airline_project` folder, simply run:

```
make
```

This compiles every file in `src/` using the headers in `include/` and
produces an executable called `airline` in the project root.

To clean up all object files and the executable:

```
make clean
```

## How to Run

```
./airline
```

The program automatically loads `data/flights.txt` on startup (if it
exists) and saves back to the same file whenever you choose option 15
("Save Data") or option 0 ("Exit").

A ready-made sample data file with 10 flights, 8 passengers, and 5
tickets is already included so you can explore the system immediately
without adding data manually.

## Menu Overview

| Option | Action                                |
|--------|----------------------------------------|
| 1      | Add Flight (Domestic / International / Charter) |
| 2      | Remove Flight                          |
| 3      | List All Flights                       |
| 4      | Search Flight by Number                |
| 5      | Search Flights by Route                |
| 6      | Search Flights by Date                 |
| 7      | Register Passenger (Economy / Business / First Class) |
| 8      | Remove Passenger                       |
| 9      | View Passenger Booking History         |
| 10     | Book Ticket                            |
| 11     | Cancel Ticket                          |
| 12     | Today's Departures                     |
| 13     | Occupancy Report                       |
| 14     | Top Revenue Flights                    |
| 15     | Save Data                              |
| 0      | Exit (saves automatically)             |

## Known Limitation

Passenger names and flight IDs are read with `cin >>`, which stops at
the first space. Please enter single-word names (e.g. `John` or
`John_Smith`) when adding new flights or passengers through the menu.
Names already stored in the sample data file are not affected by this,
since the file is read line by line, not with `cin >>`.

## Sample Flight Numbers (from data/flights.txt)

PK101, PK102, PK103, PK104 (Domestic)
PK201, PK202, PK203, PK204 (International)
PK301, PK302 (Charter)

## Sample Passenger IDs (from data/flights.txt)

P001 - P008
