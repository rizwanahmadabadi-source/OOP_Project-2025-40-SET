#ifndef AIRLINE_H
#define AIRLINE_H

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include "Flight.h"
#include "Passenger.h"
#include "Ticket.h"
using namespace std;

// Airline class, holds everything together
class Airline
{
private:
    vector<Flight*> flights;
    vector<Passenger*> passengers;
    vector<Ticket*> tickets;
    map<string, int> flightIndex;
    int ticketCounter;

public:
    Airline();
    ~Airline();

    // Flight management
    void addFlight(Flight* flight);
    void removeFlight(string flightNumber);
    Flight* searchFlightByNumber(string flightNumber);
    void searchFlightsByRoute(string origin, string destination);
    void searchFlightsByDate(string date);
    void listAllFlights();

    // Passenger management
    void registerPassenger(Passenger* passenger);
    void removePassenger(string passengerId);
    Passenger* searchPassengerById(string passengerId);
    void viewBookingHistory(string passengerId);

    // Booking
    void bookTicket(string passengerId, string flightNumber, int seatNumber);
    void cancelTicket(string ticketId, int daysBeforeDeparture);

    // Reports
    void todaysDepartures(string todayDate);
    void occupancyReport();
    void topRevenueFlights();

    // Persistence
    void saveToFile(string filename);
    void loadFromFile(string filename);
};

#endif
