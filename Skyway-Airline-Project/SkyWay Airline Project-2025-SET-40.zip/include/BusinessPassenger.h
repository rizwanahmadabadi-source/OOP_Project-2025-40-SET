#ifndef BUSINESSPASSENGER_H
#define BUSINESSPASSENGER_H

#include "Passenger.h"

// Business class passenger
class BusinessPassenger : public Passenger
{
public:
    BusinessPassenger();
    BusinessPassenger(string passengerId, string name);
    ~BusinessPassenger();

    double getBaggageAllowance();
    double getRefundPercentage(int daysBeforeDeparture);
    double getLoyaltyMultiplier();
    void displayDetails();
    string getType();
    string toFileString();
};

#endif
