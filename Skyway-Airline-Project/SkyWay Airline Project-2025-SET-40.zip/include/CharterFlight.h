#ifndef CHARTERFLIGHT_H
#define CHARTERFLIGHT_H

#include "Flight.h"

// Charter flight, booked privately by a company or group
class CharterFlight : public Flight
{
private:
    string contractHolder;
    double contractFee;

public:
    CharterFlight();
    CharterFlight(string flightNumber, string origin, string destination, string departureDate, string departureTime, int totalSeats, string contractHolder, double contractFee);
    ~CharterFlight();

    string getContractHolder();
    double getContractFee();

    double calculateBaseFare();
    void displayDetails();
    string getType();
    string toFileString();
};

#endif
