#ifndef DOMESTICFLIGHT_H
#define DOMESTICFLIGHT_H

#include "Flight.h"

// Domestic flight, short routes inside the same country
class DomesticFlight : public Flight
{
private:
    double taxPercent;

public:
    DomesticFlight();
    DomesticFlight(string flightNumber, string origin, string destination, string departureDate, string departureTime, int totalSeats, double taxPercent);
    ~DomesticFlight();

    double getTaxPercent();

    double calculateBaseFare();
    void displayDetails();
    string getType();
    string toFileString();
};

#endif
