#ifndef ECONOMYPASSENGER_H
#define ECONOMYPASSENGER_H

#include "Passenger.h"

// Economy class passenger
class EconomyPassenger : public Passenger
{
public:
    EconomyPassenger();
    EconomyPassenger(string passengerId, string name);
    ~EconomyPassenger();

    double getBaggageAllowance();
    double getRefundPercentage(int daysBeforeDeparture);
    double getLoyaltyMultiplier();
    void displayDetails();
    string getType();
    string toFileString();
};

#endif
