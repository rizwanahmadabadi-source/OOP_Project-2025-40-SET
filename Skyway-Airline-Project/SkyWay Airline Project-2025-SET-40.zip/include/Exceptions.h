#ifndef EXCEPTIONS_H
#define EXCEPTIONS_H

#include <exception>
#include <string>
using namespace std;

// Thrown when a flight has no available seats
class FlightFullException : public exception
{
private:
    string message;

public:
    FlightFullException(string message);
    const char* what() const throw();
};

// Thrown when a cancellation cannot be done
class InvalidCancellationException : public exception
{
private:
    string message;

public:
    InvalidCancellationException(string message);
    const char* what() const throw();
};

// Thrown when a flight number does not exist
class FlightNotFoundException : public exception
{
private:
    string message;

public:
    FlightNotFoundException(string message);
    const char* what() const throw();
};

// Thrown when a passenger id does not exist
class PassengerNotFoundException : public exception
{
private:
    string message;

public:
    PassengerNotFoundException(string message);
    const char* what() const throw();
};

// Thrown when a passenger tries to book the same flight twice
class DuplicateBookingException : public exception
{
private:
    string message;

public:
    DuplicateBookingException(string message);
    const char* what() const throw();
};

#endif
