#ifndef FIRSTCLASSPASSENGER_H
#define FIRSTCLASSPASSENGER_H

#include "Passenger.h"

// First class passenger
class FirstClassPassenger : public Passenger
{
public:
    FirstClassPassenger();
    FirstClassPassenger(string passengerId, string name);
    ~FirstClassPassenger();

    double getBaggageAllowance();
    double getRefundPercentage(int daysBeforeDeparture);
    double getLoyaltyMultiplier();
    void displayDetails();
    string getType();
    string toFileString();
};

#endif
