#ifndef FLIGHT_H
#define FLIGHT_H

#include <iostream>
#include <string>
using namespace std;

// Abstract base class for all flight types
class Flight
{
protected:
    string flightNumber;
    string origin;
    string destination;
    string departureDate;
    string departureTime;
    int totalSeats;
    int availableSeats;

public:
    Flight();
    Flight(string flightNumber, string origin, string destination, string departureDate, string departureTime, int totalSeats);
    virtual ~Flight();

    // Getters
    string getFlightNumber();
    string getOrigin();
    string getDestination();
    string getDepartureDate();
    string getDepartureTime();
    int getTotalSeats();
    int getAvailableSeats();
    string getId();

    // Seat handling
    void bookSeat();
    void cancelSeat();
    bool isFull();

    // Pure virtual functions, must be implemented by derived classes
    virtual double calculateBaseFare() = 0;
    virtual void displayDetails() = 0;
    virtual string getType() = 0;
    virtual string toFileString() = 0;

    // Operator overloading
    friend ostream& operator<<(ostream& out, Flight& flight);
};

#endif
