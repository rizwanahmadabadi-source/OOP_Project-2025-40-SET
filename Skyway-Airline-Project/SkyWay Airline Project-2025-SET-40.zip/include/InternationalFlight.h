#ifndef INTERNATIONALFLIGHT_H
#define INTERNATIONALFLIGHT_H

#include "Flight.h"

// International flight, crosses country borders
class InternationalFlight : public Flight
{
private:
    bool visaRequired;

public:
    InternationalFlight();
    InternationalFlight(string flightNumber, string origin, string destination, string departureDate, string departureTime, int totalSeats, bool visaRequired);
    ~InternationalFlight();

    bool getVisaRequired();

    double calculateBaseFare();
    void displayDetails();
    string getType();
    string toFileString();
};

#endif
