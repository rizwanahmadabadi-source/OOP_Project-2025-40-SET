#ifndef PASSENGER_H
#define PASSENGER_H

#include <iostream>
#include <string>
using namespace std;

// Abstract base class for all passenger types
class Passenger
{
protected:
    string passengerId;
    string name;
    int loyaltyPoints;

public:
    Passenger();
    Passenger(string passengerId, string name);
    virtual ~Passenger();

    // Getters
    string getPassengerId();
    string getName();
    int getLoyaltyPoints();
    string getId();

    // Add loyalty points after a booking
    void addLoyaltyPoints(int points);

    // Pure virtual functions, each passenger type is different
    virtual double getBaggageAllowance() = 0;
    virtual double getRefundPercentage(int daysBeforeDeparture) = 0;
    virtual double getLoyaltyMultiplier() = 0;
    virtual void displayDetails() = 0;
    virtual string getType() = 0;
    virtual string toFileString() = 0;
};

#endif
