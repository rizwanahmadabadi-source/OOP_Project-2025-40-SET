#ifndef SEARCHUTIL_H
#define SEARCHUTIL_H

#include <vector>
#include <string>
using namespace std;

// Generic search function
// Works for any list of pointers as long as the object has a getId() function
// Used for both Flight objects and Passenger objects
template <typename T>
T* searchById(vector<T*> list, string id)
{
    for (int i = 0; i < (int)list.size(); i++)
    {
        if (list[i]->getId() == id)
        {
            return list[i];
        }
    }

    return NULL;
}

#endif
