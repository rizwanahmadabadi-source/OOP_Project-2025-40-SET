#ifndef TICKET_H
#define TICKET_H

#include <iostream>
#include <string>
using namespace std;

// Ticket links one passenger to one flight
class Ticket
{
private:
    string ticketId;
    string passengerId;
    string flightNumber;
    int seatNumber;
    double farePaid;
    string status;

public:
    Ticket();
    Ticket(string ticketId, string passengerId, string flightNumber, int seatNumber, double farePaid);
    ~Ticket();

    // Getters
    string getTicketId();
    string getPassengerId();
    string getFlightNumber();
    int getSeatNumber();
    double getFarePaid();
    string getStatus();

    // Setter
    void setStatus(string status);

    // Turn this object into one line of text for the save file
    string toFileString();

    // Operator overloading
    bool operator==(Ticket other);
    friend ostream& operator<<(ostream& out, Ticket& ticket);
};

#endif
