#include "Airline.h"
#include "DomesticFlight.h"
#include "InternationalFlight.h"
#include "CharterFlight.h"
#include "EconomyPassenger.h"
#include "BusinessPassenger.h"
#include "FirstClassPassenger.h"
#include "Exceptions.h"
#include "SearchUtil.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstdlib>
using namespace std;

// Small helper function, splits a line of text by a separator character
// Not a member of Airline, just used inside this file for file loading
vector<string> splitLine(string line, char separator)
{
    vector<string> parts;
    string current = "";

    for (int i = 0; i < (int)line.size(); i++)
    {
        if (line[i] == separator)
        {
            parts.push_back(current);
            current = "";
        }
        else
        {
            current = current + line[i];
        }
    }

    parts.push_back(current);

    return parts;
}

// Used with sort() to order revenue pairs from highest to lowest
bool compareRevenue(pair<string, double> a, pair<string, double> b)
{
    if (a.second > b.second)
    {
        return true;
    }

    return false;
}

// Constructor
Airline::Airline()
{
    ticketCounter = 1;
}

// Destructor, cleans up all dynamically allocated objects
Airline::~Airline()
{
    for (int i = 0; i < (int)flights.size(); i++)
    {
        delete flights[i];
    }

    for (int i = 0; i < (int)passengers.size(); i++)
    {
        delete passengers[i];
    }

    for (int i = 0; i < (int)tickets.size(); i++)
    {
        delete tickets[i];
    }
}

// ---------------- Flight management ----------------

// Add a new flight
void Airline::addFlight(Flight* flight)
{
    flightIndex[flight->getFlightNumber()] = flights.size();
    flights.push_back(flight);
    cout << "Flight " << flight->getFlightNumber() << " added." << endl;
}

// Remove a flight by flight number
void Airline::removeFlight(string flightNumber)
{
    int position = -1;

    for (int i = 0; i < (int)flights.size(); i++)
    {
        if (flights[i]->getFlightNumber() == flightNumber)
        {
            position = i;
        }
    }

    if (position == -1)
    {
        throw FlightNotFoundException("Flight not found: " + flightNumber);
    }

    delete flights[position];
    flights.erase(flights.begin() + position);

    // Rebuild the index map since positions shifted
    flightIndex.clear();
    for (int i = 0; i < (int)flights.size(); i++)
    {
        flightIndex[flights[i]->getFlightNumber()] = i;
    }

    cout << "Flight " << flightNumber << " removed." << endl;
}

// Search flight by flight number, uses the generic template function
Flight* Airline::searchFlightByNumber(string flightNumber)
{
    return searchById(flights, flightNumber);
}

// Search flights by route
void Airline::searchFlightsByRoute(string origin, string destination)
{
    bool found = false;

    for (int i = 0; i < (int)flights.size(); i++)
    {
        if (flights[i]->getOrigin() == origin && flights[i]->getDestination() == destination)
        {
            cout << *flights[i] << endl;
            found = true;
        }
    }

    if (found == false)
    {
        cout << "No flights found for that route." << endl;
    }
}

// Search flights by date
void Airline::searchFlightsByDate(string date)
{
    bool found = false;

    for (int i = 0; i < (int)flights.size(); i++)
    {
        if (flights[i]->getDepartureDate() == date)
        {
            cout << *flights[i] << endl;
            found = true;
        }
    }

    if (found == false)
    {
        cout << "No flights found for that date." << endl;
    }
}

// List all flights
void Airline::listAllFlights()
{
    if (flights.size() == 0)
    {
        cout << "No flights in the system." << endl;
        return;
    }

    for (int i = 0; i < (int)flights.size(); i++)
    {
        cout << *flights[i] << endl;
    }
}

// ---------------- Passenger management ----------------

// Register a new passenger
void Airline::registerPassenger(Passenger* passenger)
{
    passengers.push_back(passenger);
    cout << "Passenger " << passenger->getPassengerId() << " registered." << endl;
}

// Remove a passenger by id
void Airline::removePassenger(string passengerId)
{
    int position = -1;

    for (int i = 0; i < (int)passengers.size(); i++)
    {
        if (passengers[i]->getPassengerId() == passengerId)
        {
            position = i;
        }
    }

    if (position == -1)
    {
        throw PassengerNotFoundException("Passenger not found: " + passengerId);
    }

    delete passengers[position];
    passengers.erase(passengers.begin() + position);

    cout << "Passenger " << passengerId << " removed." << endl;
}

// Search passenger by id, uses the generic template function
Passenger* Airline::searchPassengerById(string passengerId)
{
    return searchById(passengers, passengerId);
}

// Show a passenger's booking history
void Airline::viewBookingHistory(string passengerId)
{
    bool found = false;

    for (int i = 0; i < (int)tickets.size(); i++)
    {
        if (tickets[i]->getPassengerId() == passengerId)
        {
            cout << *tickets[i] << endl;
            found = true;
        }
    }

    if (found == false)
    {
        cout << "No booking history for this passenger." << endl;
    }
}

// ---------------- Booking ----------------

// Book a ticket for a passenger on a flight
void Airline::bookTicket(string passengerId, string flightNumber, int seatNumber)
{
    Passenger* passenger = searchPassengerById(passengerId);
    Flight* flight = searchFlightByNumber(flightNumber);

    if (passenger == NULL)
    {
        throw PassengerNotFoundException("Passenger not found: " + passengerId);
    }

    if (flight == NULL)
    {
        throw FlightNotFoundException("Flight not found: " + flightNumber);
    }

    if (flight->isFull())
    {
        throw FlightFullException("Flight is full: " + flightNumber);
    }

    // Check if the passenger already has an active ticket on this flight
    for (int i = 0; i < (int)tickets.size(); i++)
    {
        if (tickets[i]->getPassengerId() == passengerId && tickets[i]->getFlightNumber() == flightNumber && tickets[i]->getStatus() == "ACTIVE")
        {
            throw DuplicateBookingException("Passenger already has a ticket on this flight.");
        }
    }

    double fare = flight->calculateBaseFare();
    string ticketId = "T" + to_string(ticketCounter);
    ticketCounter = ticketCounter + 1;

    Ticket* ticket = new Ticket(ticketId, passengerId, flightNumber, seatNumber, fare);
    tickets.push_back(ticket);

    flight->bookSeat();

    int points = (int)(fare * 0.01 * passenger->getLoyaltyMultiplier());
    passenger->addLoyaltyPoints(points);

    cout << "Booking successful. Ticket ID: " << ticketId << " Fare: " << fare << endl;
}

// Cancel a ticket and calculate the refund
void Airline::cancelTicket(string ticketId, int daysBeforeDeparture)
{
    Ticket* ticket = NULL;

    for (int i = 0; i < (int)tickets.size(); i++)
    {
        if (tickets[i]->getTicketId() == ticketId)
        {
            ticket = tickets[i];
        }
    }

    if (ticket == NULL)
    {
        throw InvalidCancellationException("Ticket not found: " + ticketId);
    }

    if (ticket->getStatus() == "CANCELLED")
    {
        throw InvalidCancellationException("Ticket already cancelled: " + ticketId);
    }

    Passenger* passenger = searchPassengerById(ticket->getPassengerId());
    Flight* flight = searchFlightByNumber(ticket->getFlightNumber());

    if (passenger == NULL || flight == NULL)
    {
        throw InvalidCancellationException("Cannot process cancellation, data missing.");
    }

    double refundPercent = passenger->getRefundPercentage(daysBeforeDeparture);
    double refundAmount = ticket->getFarePaid() * (refundPercent / 100.0);

    ticket->setStatus("CANCELLED");
    flight->cancelSeat();

    cout << "Ticket " << ticketId << " cancelled. Refund percent: " << refundPercent << "% Refund amount: " << refundAmount << endl;
}

// ---------------- Reports ----------------

// List flights departing today
void Airline::todaysDepartures(string todayDate)
{
    bool found = false;

    for (int i = 0; i < (int)flights.size(); i++)
    {
        if (flights[i]->getDepartureDate() == todayDate)
        {
            cout << *flights[i] << endl;
            found = true;
        }
    }

    if (found == false)
    {
        cout << "No departures today." << endl;
    }
}

// Show occupancy percentage per flight
void Airline::occupancyReport()
{
    if (flights.size() == 0)
    {
        cout << "No flights in the system." << endl;
        return;
    }

    for (int i = 0; i < (int)flights.size(); i++)
    {
        int total = flights[i]->getTotalSeats();
        int available = flights[i]->getAvailableSeats();
        int booked = total - available;
        double occupancy = 0.0;

        if (total > 0)
        {
            occupancy = (double)booked / (double)total * 100.0;
        }

        cout << "Flight " << flights[i]->getFlightNumber() << " occupancy: " << occupancy << "%" << endl;
    }
}

// Show the top 5 highest revenue flights, uses sort() from the STL
void Airline::topRevenueFlights()
{
    vector<pair<string, double> > revenueList;

    for (int i = 0; i < (int)flights.size(); i++)
    {
        double revenue = 0.0;

        for (int j = 0; j < (int)tickets.size(); j++)
        {
            if (tickets[j]->getFlightNumber() == flights[i]->getFlightNumber() && tickets[j]->getStatus() == "ACTIVE")
            {
                revenue = revenue + tickets[j]->getFarePaid();
            }
        }

        pair<string, double> entry;
        entry.first = flights[i]->getFlightNumber();
        entry.second = revenue;
        revenueList.push_back(entry);
    }

    sort(revenueList.begin(), revenueList.end(), compareRevenue);

    int count = 5;
    if (revenueList.size() < 5)
    {
        count = revenueList.size();
    }

    cout << "Top " << count << " highest revenue flights:" << endl;

    for (int i = 0; i < count; i++)
    {
        cout << i + 1 << ". Flight " << revenueList[i].first << " - Revenue: " << revenueList[i].second << endl;
    }
}

// ---------------- Persistence ----------------

// Save all flights, passengers, and tickets to a text file
void Airline::saveToFile(string filename)
{
    ofstream outFile(filename.c_str());

    if (!outFile.is_open())
    {
        cout << "Could not open file for saving." << endl;
        return;
    }

    outFile << "#FLIGHTS" << endl;
    for (int i = 0; i < (int)flights.size(); i++)
    {
        outFile << flights[i]->toFileString() << endl;
    }

    outFile << "#PASSENGERS" << endl;
    for (int i = 0; i < (int)passengers.size(); i++)
    {
        outFile << passengers[i]->toFileString() << endl;
    }

    outFile << "#TICKETS" << endl;
    for (int i = 0; i < (int)tickets.size(); i++)
    {
        outFile << tickets[i]->toFileString() << endl;
    }

    outFile << "#COUNTER" << endl;
    outFile << ticketCounter << endl;

    outFile.close();
    cout << "Data saved to " << filename << endl;
}

// Load flights, passengers, and tickets from a text file
void Airline::loadFromFile(string filename)
{
    ifstream inFile(filename.c_str());

    if (!inFile.is_open())
    {
        cout << "No existing data file found. Starting fresh." << endl;
        return;
    }

    // Clear any existing data first
    for (int i = 0; i < (int)flights.size(); i++)
    {
        delete flights[i];
    }
    flights.clear();
    flightIndex.clear();

    for (int i = 0; i < (int)passengers.size(); i++)
    {
        delete passengers[i];
    }
    passengers.clear();

    for (int i = 0; i < (int)tickets.size(); i++)
    {
        delete tickets[i];
    }
    tickets.clear();

    string line;
    string section = "";

    while (getline(inFile, line))
    {
        if (line.size() == 0)
        {
            continue;
        }

        if (line == "#FLIGHTS" || line == "#PASSENGERS" || line == "#TICKETS" || line == "#COUNTER")
        {
            section = line;
            continue;
        }

        if (section == "#FLIGHTS")
        {
            vector<string> parts = splitLine(line, '|');
            string type = parts[0];

            if (type == "DOMESTIC")
            {
                Flight* flight = new DomesticFlight(parts[1], parts[2], parts[3], parts[4], parts[5], atoi(parts[6].c_str()), atof(parts[8].c_str()));
                for (int k = 0; k < atoi(parts[6].c_str()) - atoi(parts[7].c_str()); k++)
                {
                    flight->bookSeat();
                }
                flightIndex[flight->getFlightNumber()] = flights.size();
                flights.push_back(flight);
            }
            else if (type == "INTERNATIONAL")
            {
                bool visa = false;
                if (parts[8] == "1")
                {
                    visa = true;
                }

                Flight* flight = new InternationalFlight(parts[1], parts[2], parts[3], parts[4], parts[5], atoi(parts[6].c_str()), visa);
                for (int k = 0; k < atoi(parts[6].c_str()) - atoi(parts[7].c_str()); k++)
                {
                    flight->bookSeat();
                }
                flightIndex[flight->getFlightNumber()] = flights.size();
                flights.push_back(flight);
            }
            else if (type == "CHARTER")
            {
                Flight* flight = new CharterFlight(parts[1], parts[2], parts[3], parts[4], parts[5], atoi(parts[6].c_str()), parts[8], atof(parts[9].c_str()));
                for (int k = 0; k < atoi(parts[6].c_str()) - atoi(parts[7].c_str()); k++)
                {
                    flight->bookSeat();
                }
                flightIndex[flight->getFlightNumber()] = flights.size();
                flights.push_back(flight);
            }
        }
        else if (section == "#PASSENGERS")
        {
            vector<string> parts = splitLine(line, '|');
            string type = parts[0];
            Passenger* passenger = NULL;

            if (type == "ECONOMY")
            {
                passenger = new EconomyPassenger(parts[1], parts[2]);
            }
            else if (type == "BUSINESS")
            {
                passenger = new BusinessPassenger(parts[1], parts[2]);
            }
            else if (type == "FIRSTCLASS")
            {
                passenger = new FirstClassPassenger(parts[1], parts[2]);
            }

            if (passenger != NULL)
            {
                passenger->addLoyaltyPoints(atoi(parts[3].c_str()));
                passengers.push_back(passenger);
            }
        }
        else if (section == "#TICKETS")
        {
            vector<string> parts = splitLine(line, '|');
            Ticket* ticket = new Ticket(parts[0], parts[1], parts[2], atoi(parts[3].c_str()), atof(parts[4].c_str()));
            ticket->setStatus(parts[5]);
            tickets.push_back(ticket);
        }
        else if (section == "#COUNTER")
        {
            ticketCounter = atoi(line.c_str());
        }
    }

    inFile.close();
    cout << "Data loaded from " << filename << endl;
}
