#include "BusinessPassenger.h"

// Default constructor
BusinessPassenger::BusinessPassenger() : Passenger()
{
    // Nothing extra to set
}

// Constructor
BusinessPassenger::BusinessPassenger(string passengerId, string name) : Passenger(passengerId, name)
{
    // Nothing extra to set
}

// Destructor
BusinessPassenger::~BusinessPassenger()
{
    // Nothing special to clean up
}

// Business passengers get 30 kg baggage
double BusinessPassenger::getBaggageAllowance()
{
    return 30.0;
}

// Refund rules for business passengers
double BusinessPassenger::getRefundPercentage(int daysBeforeDeparture)
{
    if (daysBeforeDeparture >= 7)
    {
        return 90.0;
    }
    else if (daysBeforeDeparture >= 2)
    {
        return 60.0;
    }

    return 30.0;
}

// Loyalty multiplier for business
double BusinessPassenger::getLoyaltyMultiplier()
{
    return 1.5;
}

// Show passenger details
void BusinessPassenger::displayDetails()
{
    cout << "---- Business Passenger ----" << endl;
    cout << "ID             : " << passengerId << endl;
    cout << "Name           : " << name << endl;
    cout << "Loyalty Points : " << loyaltyPoints << endl;
    cout << "Baggage        : " << getBaggageAllowance() << " kg" << endl;
}

// Get type name
string BusinessPassenger::getType()
{
    return "BUSINESS";
}

// Turn this object into one line of text for the save file
string BusinessPassenger::toFileString()
{
    string line = "BUSINESS|" + passengerId + "|" + name + "|" + to_string(loyaltyPoints);

    return line;
}
