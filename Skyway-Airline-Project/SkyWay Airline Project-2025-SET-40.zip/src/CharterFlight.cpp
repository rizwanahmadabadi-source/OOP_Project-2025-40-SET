#include "CharterFlight.h"

// Default constructor
CharterFlight::CharterFlight() : Flight()
{
    contractHolder = "";
    contractFee = 0.0;
}

// Constructor
CharterFlight::CharterFlight(string flightNumber, string origin, string destination, string departureDate, string departureTime, int totalSeats, string contractHolder, double contractFee)
    : Flight(flightNumber, origin, destination, departureDate, departureTime, totalSeats)
{
    this->contractHolder = contractHolder;
    this->contractFee = contractFee;
}

// Destructor
CharterFlight::~CharterFlight()
{
    // Nothing special to clean up
}

// Get contract holder name
string CharterFlight::getContractHolder()
{
    return contractHolder;
}

// Get contract fee
double CharterFlight::getContractFee()
{
    return contractFee;
}

// Charter fare is the flat contract fee split across all seats
double CharterFlight::calculateBaseFare()
{
    if (totalSeats == 0)
    {
        return 0.0;
    }

    return contractFee / totalSeats;
}

// Show flight details on screen
void CharterFlight::displayDetails()
{
    cout << "---- Charter Flight ----" << endl;
    cout << "Flight Number    : " << flightNumber << endl;
    cout << "Route            : " << origin << " -> " << destination << endl;
    cout << "Departure        : " << departureDate << " " << departureTime << endl;
    cout << "Seats            : " << availableSeats << "/" << totalSeats << endl;
    cout << "Contract Holder  : " << contractHolder << endl;
    cout << "Contract Fee     : " << contractFee << endl;
    cout << "Base Fare (each) : " << calculateBaseFare() << endl;
}

// Get the type name
string CharterFlight::getType()
{
    return "CHARTER";
}

// Turn this object into one line of text for the save file
string CharterFlight::toFileString()
{
    string line = "CHARTER|" + flightNumber + "|" + origin + "|" + destination + "|" + departureDate + "|" + departureTime;
    line = line + "|" + to_string(totalSeats) + "|" + to_string(availableSeats) + "|" + contractHolder + "|" + to_string(contractFee);

    return line;
}
