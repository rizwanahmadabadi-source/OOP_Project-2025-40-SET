#include "DomesticFlight.h"

// Default constructor
DomesticFlight::DomesticFlight() : Flight()
{
    taxPercent = 5.0;
}

// Constructor
DomesticFlight::DomesticFlight(string flightNumber, string origin, string destination, string departureDate, string departureTime, int totalSeats, double taxPercent)
    : Flight(flightNumber, origin, destination, departureDate, departureTime, totalSeats)
{
    this->taxPercent = taxPercent;
}

// Destructor
DomesticFlight::~DomesticFlight()
{
    // Nothing special to clean up
}

// Get tax percent
double DomesticFlight::getTaxPercent()
{
    return taxPercent;
}

// Domestic fare is a flat base price plus a small tax
double DomesticFlight::calculateBaseFare()
{
    double basePrice = 8000.0;
    double tax = basePrice * (taxPercent / 100.0);

    return basePrice + tax;
}

// Show flight details on screen
void DomesticFlight::displayDetails()
{
    cout << "---- Domestic Flight ----" << endl;
    cout << "Flight Number : " << flightNumber << endl;
    cout << "Route         : " << origin << " -> " << destination << endl;
    cout << "Departure     : " << departureDate << " " << departureTime << endl;
    cout << "Seats         : " << availableSeats << "/" << totalSeats << endl;
    cout << "Tax Percent   : " << taxPercent << "%" << endl;
    cout << "Base Fare     : " << calculateBaseFare() << endl;
}

// Get the type name, used for reports and file saving
string DomesticFlight::getType()
{
    return "DOMESTIC";
}

// Turn this object into one line of text for the save file
string DomesticFlight::toFileString()
{
    string line = "DOMESTIC|" + flightNumber + "|" + origin + "|" + destination + "|" + departureDate + "|" + departureTime;
    line = line + "|" + to_string(totalSeats) + "|" + to_string(availableSeats) + "|" + to_string(taxPercent);

    return line;
}
