#include "EconomyPassenger.h"

// Default constructor
EconomyPassenger::EconomyPassenger() : Passenger()
{
    // Nothing extra to set
}

// Constructor
EconomyPassenger::EconomyPassenger(string passengerId, string name) : Passenger(passengerId, name)
{
    // Nothing extra to set
}

// Destructor
EconomyPassenger::~EconomyPassenger()
{
    // Nothing special to clean up
}

// Economy passengers get 20 kg baggage
double EconomyPassenger::getBaggageAllowance()
{
    return 20.0;
}

// Refund rules for economy passengers
double EconomyPassenger::getRefundPercentage(int daysBeforeDeparture)
{
    if (daysBeforeDeparture >= 7)
    {
        return 50.0;
    }
    else if (daysBeforeDeparture >= 2)
    {
        return 20.0;
    }

    return 0.0;
}

// Loyalty multiplier for economy
double EconomyPassenger::getLoyaltyMultiplier()
{
    return 1.0;
}

// Show passenger details
void EconomyPassenger::displayDetails()
{
    cout << "---- Economy Passenger ----" << endl;
    cout << "ID             : " << passengerId << endl;
    cout << "Name           : " << name << endl;
    cout << "Loyalty Points : " << loyaltyPoints << endl;
    cout << "Baggage        : " << getBaggageAllowance() << " kg" << endl;
}

// Get type name
string EconomyPassenger::getType()
{
    return "ECONOMY";
}

// Turn this object into one line of text for the save file
string EconomyPassenger::toFileString()
{
    string line = "ECONOMY|" + passengerId + "|" + name + "|" + to_string(loyaltyPoints);

    return line;
}
