#include "Exceptions.h"

// FlightFullException constructor
FlightFullException::FlightFullException(string message)
{
    this->message = message;
}

// FlightFullException message
const char* FlightFullException::what() const throw()
{
    return message.c_str();
}

// InvalidCancellationException constructor
InvalidCancellationException::InvalidCancellationException(string message)
{
    this->message = message;
}

// InvalidCancellationException message
const char* InvalidCancellationException::what() const throw()
{
    return message.c_str();
}

// FlightNotFoundException constructor
FlightNotFoundException::FlightNotFoundException(string message)
{
    this->message = message;
}

// FlightNotFoundException message
const char* FlightNotFoundException::what() const throw()
{
    return message.c_str();
}

// PassengerNotFoundException constructor
PassengerNotFoundException::PassengerNotFoundException(string message)
{
    this->message = message;
}

// PassengerNotFoundException message
const char* PassengerNotFoundException::what() const throw()
{
    return message.c_str();
}

// DuplicateBookingException constructor
DuplicateBookingException::DuplicateBookingException(string message)
{
    this->message = message;
}

// DuplicateBookingException message
const char* DuplicateBookingException::what() const throw()
{
    return message.c_str();
}
