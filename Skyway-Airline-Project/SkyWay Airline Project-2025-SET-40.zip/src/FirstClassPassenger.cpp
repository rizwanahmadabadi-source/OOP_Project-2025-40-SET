#include "FirstClassPassenger.h"

// Default constructor
FirstClassPassenger::FirstClassPassenger() : Passenger()
{
    // Nothing extra to set
}

// Constructor
FirstClassPassenger::FirstClassPassenger(string passengerId, string name) : Passenger(passengerId, name)
{
    // Nothing extra to set
}

// Destructor
FirstClassPassenger::~FirstClassPassenger()
{
    // Nothing special to clean up
}

// First class passengers get 40 kg baggage
double FirstClassPassenger::getBaggageAllowance()
{
    return 40.0;
}

// Refund rules for first class passengers
double FirstClassPassenger::getRefundPercentage(int daysBeforeDeparture)
{
    if (daysBeforeDeparture >= 1)
    {
        return 100.0;
    }

    return 50.0;
}

// Loyalty multiplier for first class
double FirstClassPassenger::getLoyaltyMultiplier()
{
    return 2.0;
}

// Show passenger details
void FirstClassPassenger::displayDetails()
{
    cout << "---- First Class Passenger ----" << endl;
    cout << "ID             : " << passengerId << endl;
    cout << "Name           : " << name << endl;
    cout << "Loyalty Points : " << loyaltyPoints << endl;
    cout << "Baggage        : " << getBaggageAllowance() << " kg" << endl;
}

// Get type name
string FirstClassPassenger::getType()
{
    return "FIRSTCLASS";
}

// Turn this object into one line of text for the save file
string FirstClassPassenger::toFileString()
{
    string line = "FIRSTCLASS|" + passengerId + "|" + name + "|" + to_string(loyaltyPoints);

    return line;
}
