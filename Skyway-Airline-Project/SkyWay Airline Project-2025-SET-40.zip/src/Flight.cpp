#include "Flight.h"

// Default constructor
Flight::Flight()
{
    flightNumber = "";
    origin = "";
    destination = "";
    departureDate = "";
    departureTime = "";
    totalSeats = 0;
    availableSeats = 0;
}

// Constructor
Flight::Flight(string flightNumber, string origin, string destination, string departureDate, string departureTime, int totalSeats)
{
    this->flightNumber = flightNumber;
    this->origin = origin;
    this->destination = destination;
    this->departureDate = departureDate;
    this->departureTime = departureTime;
    this->totalSeats = totalSeats;
    this->availableSeats = totalSeats;
}

// Destructor
Flight::~Flight()
{
    // Nothing special to clean up here
}

// Get flight number
string Flight::getFlightNumber()
{
    return flightNumber;
}

// Get origin
string Flight::getOrigin()
{
    return origin;
}

// Get destination
string Flight::getDestination()
{
    return destination;
}

// Get departure date
string Flight::getDepartureDate()
{
    return departureDate;
}

// Get departure time
string Flight::getDepartureTime()
{
    return departureTime;
}

// Get total seats
int Flight::getTotalSeats()
{
    return totalSeats;
}

// Get available seats
int Flight::getAvailableSeats()
{
    return availableSeats;
}

// Used by the generic search template, same idea as flight number
string Flight::getId()
{
    return flightNumber;
}

// Book one seat
void Flight::bookSeat()
{
    if (availableSeats > 0)
    {
        availableSeats = availableSeats - 1;
    }
}

// Cancel one seat, gives the seat back
void Flight::cancelSeat()
{
    if (availableSeats < totalSeats)
    {
        availableSeats = availableSeats + 1;
    }
}

// Check if flight is full
bool Flight::isFull()
{
    if (availableSeats <= 0)
    {
        return true;
    }

    return false;
}

// Print flight info, uses virtual functions so it works for any flight type
ostream& operator<<(ostream& out, Flight& flight)
{
    out << "Flight " << flight.flightNumber << " (" << flight.getType() << ") ";
    out << flight.origin << " -> " << flight.destination << " on " << flight.departureDate << " " << flight.departureTime;
    out << " | Seats: " << flight.availableSeats << "/" << flight.totalSeats;
    out << " | Base Fare: " << flight.calculateBaseFare();

    return out;
}
