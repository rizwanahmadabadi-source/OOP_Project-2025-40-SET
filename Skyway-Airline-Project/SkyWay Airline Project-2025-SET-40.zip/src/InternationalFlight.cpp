#include "InternationalFlight.h"

// Default constructor
InternationalFlight::InternationalFlight() : Flight()
{
    visaRequired = true;
}

// Constructor
InternationalFlight::InternationalFlight(string flightNumber, string origin, string destination, string departureDate, string departureTime, int totalSeats, bool visaRequired)
    : Flight(flightNumber, origin, destination, departureDate, departureTime, totalSeats)
{
    this->visaRequired = visaRequired;
}

// Destructor
InternationalFlight::~InternationalFlight()
{
    // Nothing special to clean up
}

// Get visa requirement
bool InternationalFlight::getVisaRequired()
{
    return visaRequired;
}

// International fare is higher, and visa flights cost a bit more
double InternationalFlight::calculateBaseFare()
{
    double basePrice = 35000.0;

    if (visaRequired == true)
    {
        basePrice = basePrice + 2500.0;
    }

    return basePrice;
}

// Show flight details on screen
void InternationalFlight::displayDetails()
{
    cout << "---- International Flight ----" << endl;
    cout << "Flight Number : " << flightNumber << endl;
    cout << "Route         : " << origin << " -> " << destination << endl;
    cout << "Departure     : " << departureDate << " " << departureTime << endl;
    cout << "Seats         : " << availableSeats << "/" << totalSeats << endl;

    if (visaRequired == true)
    {
        cout << "Visa Required : Yes" << endl;
    }
    else
    {
        cout << "Visa Required : No" << endl;
    }

    cout << "Base Fare     : " << calculateBaseFare() << endl;
}

// Get the type name
string InternationalFlight::getType()
{
    return "INTERNATIONAL";
}

// Turn this object into one line of text for the save file
string InternationalFlight::toFileString()
{
    string visaText = "0";

    if (visaRequired == true)
    {
        visaText = "1";
    }

    string line = "INTERNATIONAL|" + flightNumber + "|" + origin + "|" + destination + "|" + departureDate + "|" + departureTime;
    line = line + "|" + to_string(totalSeats) + "|" + to_string(availableSeats) + "|" + visaText;

    return line;
}
