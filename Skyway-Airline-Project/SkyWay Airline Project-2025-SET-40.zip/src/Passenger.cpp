#include "Passenger.h"

// Default constructor
Passenger::Passenger()
{
    passengerId = "";
    name = "";
    loyaltyPoints = 0;
}

// Constructor
Passenger::Passenger(string passengerId, string name)
{
    this->passengerId = passengerId;
    this->name = name;
    this->loyaltyPoints = 0;
}

// Destructor
Passenger::~Passenger()
{
    // Nothing special to clean up
}

// Get passenger id
string Passenger::getPassengerId()
{
    return passengerId;
}

// Get name
string Passenger::getName()
{
    return name;
}

// Get loyalty points
int Passenger::getLoyaltyPoints()
{
    return loyaltyPoints;
}

// Used by the generic search template
string Passenger::getId()
{
    return passengerId;
}

// Add loyalty points
void Passenger::addLoyaltyPoints(int points)
{
    loyaltyPoints = loyaltyPoints + points;
}
