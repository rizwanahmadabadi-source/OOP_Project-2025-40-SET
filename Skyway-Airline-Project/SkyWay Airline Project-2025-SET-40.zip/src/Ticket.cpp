#include "Ticket.h"

// Default constructor
Ticket::Ticket()
{
    ticketId = "";
    passengerId = "";
    flightNumber = "";
    seatNumber = 0;
    farePaid = 0.0;
    status = "ACTIVE";
}

// Constructor
Ticket::Ticket(string ticketId, string passengerId, string flightNumber, int seatNumber, double farePaid)
{
    this->ticketId = ticketId;
    this->passengerId = passengerId;
    this->flightNumber = flightNumber;
    this->seatNumber = seatNumber;
    this->farePaid = farePaid;
    this->status = "ACTIVE";
}

// Destructor
Ticket::~Ticket()
{
    // Nothing special to clean up
}

// Get ticket id
string Ticket::getTicketId()
{
    return ticketId;
}

// Get passenger id
string Ticket::getPassengerId()
{
    return passengerId;
}

// Get flight number
string Ticket::getFlightNumber()
{
    return flightNumber;
}

// Get seat number
int Ticket::getSeatNumber()
{
    return seatNumber;
}

// Get fare paid
double Ticket::getFarePaid()
{
    return farePaid;
}

// Get status
string Ticket::getStatus()
{
    return status;
}

// Set status
void Ticket::setStatus(string status)
{
    this->status = status;
}

// Turn this object into one line of text for the save file
string Ticket::toFileString()
{
    string line = ticketId + "|" + passengerId + "|" + flightNumber + "|" + to_string(seatNumber) + "|" + to_string(farePaid) + "|" + status;

    return line;
}

// Two tickets are equal if they have the same ticket id
bool Ticket::operator==(Ticket other)
{
    if (ticketId == other.ticketId)
    {
        return true;
    }

    return false;
}

// Print ticket info
ostream& operator<<(ostream& out, Ticket& ticket)
{
    out << "Ticket " << ticket.ticketId << " | Passenger: " << ticket.passengerId << " | Flight: " << ticket.flightNumber;
    out << " | Seat: " << ticket.seatNumber << " | Fare: " << ticket.farePaid << " | Status: " << ticket.status;

    return out;
}
