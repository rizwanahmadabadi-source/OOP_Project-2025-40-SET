#include <iostream>
#include <string>
#include "Airline.h"
#include "DomesticFlight.h"
#include "InternationalFlight.h"
#include "CharterFlight.h"
#include "EconomyPassenger.h"
#include "BusinessPassenger.h"
#include "FirstClassPassenger.h"
#include "Exceptions.h"
using namespace std;

// Shows the main menu
void showMenu()
{
    cout << endl;
    cout << "========= SkyLink Airways =========" << endl;
    cout << "1. Add Flight" << endl;
    cout << "2. Remove Flight" << endl;
    cout << "3. List All Flights" << endl;
    cout << "4. Search Flight by Number" << endl;
    cout << "5. Search Flights by Route" << endl;
    cout << "6. Search Flights by Date" << endl;
    cout << "7. Register Passenger" << endl;
    cout << "8. Remove Passenger" << endl;
    cout << "9. View Passenger Booking History" << endl;
    cout << "10. Book Ticket" << endl;
    cout << "11. Cancel Ticket" << endl;
    cout << "12. Today's Departures" << endl;
    cout << "13. Occupancy Report" << endl;
    cout << "14. Top Revenue Flights" << endl;
    cout << "15. Save Data" << endl;
    cout << "0. Exit" << endl;
    cout << "====================================" << endl;
    cout << "Enter your choice: ";
}

// Adds a flight based on user input
void addFlightMenu(Airline* airline)
{
    int typeChoice;
    string flightNumber, origin, destination, date, time;
    int seats;

    cout << "Choose flight type (1-Domestic, 2-International, 3-Charter): ";
    cin >> typeChoice;
    cout << "Flight Number: ";
    cin >> flightNumber;
    cout << "Origin: ";
    cin >> origin;
    cout << "Destination: ";
    cin >> destination;
    cout << "Departure Date (YYYY-MM-DD): ";
    cin >> date;
    cout << "Departure Time (HH:MM): ";
    cin >> time;
    cout << "Total Seats: ";
    cin >> seats;

    if (typeChoice == 1)
    {
        double tax;
        cout << "Tax Percent: ";
        cin >> tax;
        Flight* flight = new DomesticFlight(flightNumber, origin, destination, date, time, seats, tax);
        airline->addFlight(flight);
    }
    else if (typeChoice == 2)
    {
        int visaChoice;
        cout << "Visa Required (1-Yes, 0-No): ";
        cin >> visaChoice;
        bool visa = false;
        if (visaChoice == 1)
        {
            visa = true;
        }
        Flight* flight = new InternationalFlight(flightNumber, origin, destination, date, time, seats, visa);
        airline->addFlight(flight);
    }
    else if (typeChoice == 3)
    {
        string holder;
        double fee;
        cout << "Contract Holder: ";
        cin >> holder;
        cout << "Contract Fee: ";
        cin >> fee;
        Flight* flight = new CharterFlight(flightNumber, origin, destination, date, time, seats, holder, fee);
        airline->addFlight(flight);
    }
    else
    {
        cout << "Invalid flight type." << endl;
    }
}

// Registers a passenger based on user input
void registerPassengerMenu(Airline* airline)
{
    int typeChoice;
    string id, name;

    cout << "Choose passenger type (1-Economy, 2-Business, 3-FirstClass): ";
    cin >> typeChoice;
    cout << "Passenger ID: ";
    cin >> id;
    cout << "Name: ";
    cin >> name;

    if (typeChoice == 1)
    {
        Passenger* passenger = new EconomyPassenger(id, name);
        airline->registerPassenger(passenger);
    }
    else if (typeChoice == 2)
    {
        Passenger* passenger = new BusinessPassenger(id, name);
        airline->registerPassenger(passenger);
    }
    else if (typeChoice == 3)
    {
        Passenger* passenger = new FirstClassPassenger(id, name);
        airline->registerPassenger(passenger);
    }
    else
    {
        cout << "Invalid passenger type." << endl;
    }
}

int main()
{
    Airline airline;
    string dataFile = "data/flights.txt";

    airline.loadFromFile(dataFile);

    int choice = -1;

    while (choice != 0)
    {
        showMenu();
        cin >> choice;

        try
        {
            if (choice == 1)
            {
                addFlightMenu(&airline);
            }
            else if (choice == 2)
            {
                string flightNumber;
                cout << "Flight Number: ";
                cin >> flightNumber;
                airline.removeFlight(flightNumber);
            }
            else if (choice == 3)
            {
                airline.listAllFlights();
            }
            else if (choice == 4)
            {
                string flightNumber;
                cout << "Flight Number: ";
                cin >> flightNumber;
                Flight* flight = airline.searchFlightByNumber(flightNumber);

                if (flight == NULL)
                {
                    cout << "Flight not found." << endl;
                }
                else
                {
                    flight->displayDetails();
                }
            }
            else if (choice == 5)
            {
                string origin, destination;
                cout << "Origin: ";
                cin >> origin;
                cout << "Destination: ";
                cin >> destination;
                airline.searchFlightsByRoute(origin, destination);
            }
            else if (choice == 6)
            {
                string date;
                cout << "Date (YYYY-MM-DD): ";
                cin >> date;
                airline.searchFlightsByDate(date);
            }
            else if (choice == 7)
            {
                registerPassengerMenu(&airline);
            }
            else if (choice == 8)
            {
                string id;
                cout << "Passenger ID: ";
                cin >> id;
                airline.removePassenger(id);
            }
            else if (choice == 9)
            {
                string id;
                cout << "Passenger ID: ";
                cin >> id;
                airline.viewBookingHistory(id);
            }
            else if (choice == 10)
            {
                string passengerId, flightNumber;
                int seat;
                cout << "Passenger ID: ";
                cin >> passengerId;
                cout << "Flight Number: ";
                cin >> flightNumber;
                cout << "Seat Number: ";
                cin >> seat;
                airline.bookTicket(passengerId, flightNumber, seat);
            }
            else if (choice == 11)
            {
                string ticketId;
                int days;
                cout << "Ticket ID: ";
                cin >> ticketId;
                cout << "Days before departure: ";
                cin >> days;
                airline.cancelTicket(ticketId, days);
            }
            else if (choice == 12)
            {
                string today;
                cout << "Enter today's date (YYYY-MM-DD): ";
                cin >> today;
                airline.todaysDepartures(today);
            }
            else if (choice == 13)
            {
                airline.occupancyReport();
            }
            else if (choice == 14)
            {
                airline.topRevenueFlights();
            }
            else if (choice == 15)
            {
                airline.saveToFile(dataFile);
            }
            else if (choice == 0)
            {
                cout << "Saving data before exit..." << endl;
                airline.saveToFile(dataFile);
                cout << "Goodbye!" << endl;
            }
            else
            {
                cout << "Invalid choice, try again." << endl;
            }
        }
        catch (FlightFullException& e)
        {
            cout << "Error: " << e.what() << endl;
        }
        catch (InvalidCancellationException& e)
        {
            cout << "Error: " << e.what() << endl;
        }
        catch (FlightNotFoundException& e)
        {
            cout << "Error: " << e.what() << endl;
        }
        catch (PassengerNotFoundException& e)
        {
            cout << "Error: " << e.what() << endl;
        }
        catch (DuplicateBookingException& e)
        {
            cout << "Error: " << e.what() << endl;
        }
        catch (exception& e)
        {
            cout << "Unexpected error: " << e.what() << endl;
        }
    }

    return 0;
}
